# Introduction

Unzip archives directly into your server.

At the first time, basic authentication is setting.

Each unzipping is reported in the report.log file

Zip archives are getting from your own server or from remote access.

*Feel free to post request for your native language*.